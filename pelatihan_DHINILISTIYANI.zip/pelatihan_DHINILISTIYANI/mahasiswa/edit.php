<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) {
    echo "Sesi habis, silakan login ulang.";
    exit;
}
include "../db.php";
$db = new db;

$nim = $_GET['nim'];
$koneksi = $db->getKoneksi();
$nim_esc = $koneksi->real_escape_string($nim);
$data = $db->query("select * from tbl_mahasiswa where nim='$nim_esc'");
$row = $data->fetch_assoc();

if (!$row) {
    echo "Data tidak ditemukan.";
    exit;
}
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Mahasiswa</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="formEdit">
                <div class="form-group">
                    <label>NIM</label>
                    <input type="number" class="form-control" name="nim" value="<?php echo $row['nim']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" class="form-control" name="nama" value="<?php echo htmlspecialchars($row['nama']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <textarea class="form-control" name="alamat" required><?php echo htmlspecialchars($row['alamat']); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Jurusan</label>
                    <input type="text" class="form-control" name="jurusan" value="<?php echo htmlspecialchars($row['jurusan']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="#" id="btnBatal" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $("#formEdit").submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'mahasiswa/update.php',
            type: 'post',
            data: $(this).serialize(),
            success: function(data){
                $.ajax({
                    url: 'mahasiswa/list.php',
                    type: 'get',
                    success: function(res){
                        $('#contentData').html(res);
                    }
                });
            }
        });
    });

    $("#btnBatal").click(function(){
        $.ajax({
            url: 'mahasiswa/list.php',
            type: 'get',
            success: function(data){
                $('#contentData').html(data);
            }
        });
    });
});
</script>