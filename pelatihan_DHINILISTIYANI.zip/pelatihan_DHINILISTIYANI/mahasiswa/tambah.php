<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) {
    echo "Sesi habis, silakan login ulang.";
    exit;
}
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah Mahasiswa</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="formTambah">
                <div class="form-group">
                    <label>NIM</label>
                    <input type="number" class="form-control" name="nim" required>
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" class="form-control" name="nama" required>
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <textarea class="form-control" name="alamat" required></textarea>
                </div>
                <div class="form-group">
                    <label>Jurusan</label>
                    <input type="text" class="form-control" name="jurusan" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="#" id="btnBatal" class="btn btn-secondary">Batal</a>
            </form>
            <div id="pesan" class="mt-3"></div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $("#formTambah").submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'mahasiswa/proses_tambah.php',
            type: 'post',
            data: $(this).serialize(),
            success: function(data){
                $.ajax({
                    url: 'mahasiswa/list.php',
                    type: 'get',
                    success: function(res){
                        $('#contentData').html(res);
                    }
                });
            }
        });
    });

    $("#btnBatal").click(function(){
        $.ajax({
            url: 'mahasiswa/list.php',
            type: 'get',
            success: function(data){
                $('#contentData').html(data);
            }
        });
    });
});
</script>