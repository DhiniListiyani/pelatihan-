<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) {
    echo "Sesi habis, silakan login ulang.";
    exit;
}
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();

    $nim     = $koneksi->real_escape_string($_POST['nim']);
    $nama    = $koneksi->real_escape_string($_POST['nama']);
    $alamat  = $koneksi->real_escape_string($_POST['alamat']);
    $jurusan = $koneksi->real_escape_string($_POST['jurusan']);

    $sql = "UPDATE tbl_mahasiswa SET nama='$nama', alamat='$alamat', jurusan='$jurusan' WHERE nim='$nim'";
    $result = $db->update($sql);

    if ($result) {
        echo "sukses";
    } else {
        echo "gagal: " . $koneksi->error;
    }
}
?>