<?php

include "../db.php";

$db=new db();

$db->tambah_mahasiswa(

$_POST['nim'],
$_POST['nama'],
$_POST['jurusan']

);

header("location:../dashboard.php");

?>