<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) {
    echo "Sesi habis, silakan login ulang.";
    exit;
}
include "../db.php";
$db = new db;
$data = $db->query("select * from tbl_mahasiswa order by nim asc");
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data Mahasiswa</h1>
        <a href="#" id="btnTambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Mahasiswa
        </a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Jurusan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = $data->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $row['nim']; ?></td>
                            <td><?php echo htmlspecialchars($row['nama']); ?></td>
                            <td><?php echo htmlspecialchars($row['alamat']); ?></td>
                            <td><?php echo htmlspecialchars($row['jurusan']); ?></td>
                            <td>
                                <a href="#" class="btn btn-warning btn-sm btn-edit" data-nim="<?php echo $row['nim']; ?>"><i class="fas fa-edit"></i> Edit</a>
                                <a href="#" class="btn btn-danger btn-sm btn-hapus" data-nim="<?php echo $row['nim']; ?>"><i class="fas fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $("#btnTambah").click(function(){
        $.ajax({
            url: 'mahasiswa/tambah.php',
            type: 'get',
            success: function(data){
                $('#contentData').html(data);
            }
        });
    });

    $(".btn-edit").click(function(){
        var nim = $(this).data('nim');
        $.ajax({
            url: 'mahasiswa/edit.php',
            type: 'get',
            data: {nim: nim},
            success: function(data){
                $('#contentData').html(data);
            }
        });
    });

    $(".btn-hapus").click(function(){
        var nim = $(this).data('nim');
        if(confirm('Yakin ingin menghapus data mahasiswa NIM ' + nim + ' ?')){
            $.ajax({
                url: 'mahasiswa/hapus.php',
                type: 'get',
                data: {nim: nim},
                success: function(data){
                    $('#contentData').html(data);
                }
            });
        }
    });
});
</script>