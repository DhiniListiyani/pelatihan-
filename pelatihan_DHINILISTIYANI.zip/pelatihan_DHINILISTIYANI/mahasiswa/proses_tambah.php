<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) {
    echo "Sesi habis, silakan login ulang.";
    exit;
}
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();

    $nim     = $_POST['nim'];
    $nama    = $_POST['nama'];
    $alamat  = $_POST['alamat'];
    $jurusan = $_POST['jurusan'];

    $sql = "INSERT INTO tbl_mahasiswa (nim, nama, alamat, jurusan) 
            VALUES ('$nim', '$nama', '$alamat', '$jurusan')";
    
    if ($koneksi->query($sql)) {
        echo "sukses";
    } else {
        echo "gagal: " . $koneksi->error;
    }
}
?>