<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$koneksi = $db->getKoneksi();
$id = $koneksi->real_escape_string($_GET['id']);

$sql = "DELETE FROM tbl_krs WHERE id='$id'";
$result = $db->delete($sql);

$data = $db->query("
    SELECT k.id, mh.nama as nama_mhs, mh.nim, mk.nama as nama_matkul, jd.waktu, jd.ruang, s.semester
    FROM tbl_krs k
    JOIN tbl_mahasiswa mh ON k.nim = mh.nim
    JOIN tbl_jadwal jd ON k.id_jadwal = jd.id
    JOIN tbl_matkul mk ON jd.kd_matkul = mk.kd_matkul
    JOIN tbl_semester s ON k.kd_semester = s.kd_semester
    ORDER BY k.id ASC
");
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data KRS</h1>
        <a href="#" id="btnTambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Tambah KRS
        </a>
    </div>
    <?php if (!$result) { ?>
        <div class="alert alert-danger">Gagal menghapus data KRS.</div>
    <?php } ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead><tr><th>No</th><th>NIM</th><th>Nama Mahasiswa</th><th>Mata Kuliah</th><th>Jadwal</th><th>Semester</th><th>Aksi</th></tr></thead>
                    <tbody>
                        <?php $no = 1; while ($row = $data->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $row['nim']; ?></td>
                            <td><?php echo htmlspecialchars($row['nama_mhs']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_matkul']); ?></td>
                            <td><?php echo htmlspecialchars($row['waktu']) . ' - ' . htmlspecialchars($row['ruang']); ?></td>
                            <td><?php echo htmlspecialchars($row['semester']); ?></td>
                            <td>
                                <a href="#" class="btn btn-warning btn-sm btn-edit" data-id="<?php echo $row['id']; ?>"><i class="fas fa-edit"></i> Edit</a>
                                <a href="#" class="btn btn-danger btn-sm btn-hapus" data-id="<?php echo $row['id']; ?>"><i class="fas fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#btnTambah").click(function(){
        $.ajax({url:'krs/tambah.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
    $(".btn-edit").click(function(){
        var id = $(this).data('id');
        $.ajax({url:'krs/edit.php', type:'get', data:{id:id}, success:function(data){ $('#contentData').html(data); }});
    });
    $(".btn-hapus").click(function(){
        var id = $(this).data('id');
        if(confirm('Yakin ingin menghapus data KRS ini?')){
            $.ajax({url:'krs/hapus.php', type:'get', data:{id:id}, success:function(data){ $('#contentData').html(data); }});
        }
    });
});
</script>