<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $nim         = $koneksi->real_escape_string($_POST['nim']);
    $id_jadwal   = $koneksi->real_escape_string($_POST['id_jadwal']);
    $kd_semester = $koneksi->real_escape_string($_POST['kd_semester']);

    $sql = "INSERT INTO tbl_krs (nim, id_jadwal, kd_semester) VALUES ('$nim','$id_jadwal','$kd_semester')";
    $result = $db->insert($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>