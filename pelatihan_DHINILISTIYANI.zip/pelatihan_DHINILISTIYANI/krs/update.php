<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $id          = $koneksi->real_escape_string($_POST['id']);
    $nim         = $koneksi->real_escape_string($_POST['nim']);
    $id_jadwal   = $koneksi->real_escape_string($_POST['id_jadwal']);
    $kd_semester = $koneksi->real_escape_string($_POST['kd_semester']);

    $sql = "UPDATE tbl_krs SET nim='$nim', id_jadwal='$id_jadwal', kd_semester='$kd_semester' WHERE id='$id'";
    $result = $db->update($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>