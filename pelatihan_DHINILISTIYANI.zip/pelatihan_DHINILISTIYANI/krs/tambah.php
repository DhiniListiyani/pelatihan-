<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$mahasiswa = $db->query("select * from tbl_mahasiswa order by nama asc");
$jadwal = $db->query("
    SELECT jd.id, mk.nama as nama_matkul, jd.waktu, jd.ruang
    FROM tbl_jadwal jd
    JOIN tbl_matkul mk ON jd.kd_matkul = mk.kd_matkul
    ORDER BY jd.id ASC
");
$semester = $db->query("select * from tbl_semester order by kd_semester asc");
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah KRS</h1>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="formTambah">
                <div class="form-group">
                    <label>Mahasiswa</label>
                    <select class="form-control" name="nim" required>
                        <option value="">-- Pilih Mahasiswa --</option>
                        <?php while ($m = $mahasiswa->fetch_assoc()) { ?>
                        <option value="<?php echo $m['nim']; ?>"><?php echo $m['nim'] . ' - ' . htmlspecialchars($m['nama']); ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jadwal</label>
                    <select class="form-control" name="id_jadwal" required>
                        <option value="">-- Pilih Jadwal --</option>
                        <?php while ($j = $jadwal->fetch_assoc()) { ?>
                        <option value="<?php echo $j['id']; ?>"><?php echo htmlspecialchars($j['nama_matkul']) . ' (' . htmlspecialchars($j['waktu']) . ' - ' . htmlspecialchars($j['ruang']) . ')'; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Semester</label>
                    <select class="form-control" name="kd_semester" required>
                        <option value="">-- Pilih Semester --</option>
                        <?php while ($s = $semester->fetch_assoc()) { ?>
                        <option value="<?php echo $s['kd_semester']; ?>"><?php echo htmlspecialchars($s['semester']); ?></option>
                        <?php } ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="#" id="btnBatal" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#formTambah").submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'krs/proses_tambah.php', type: 'post', data: $(this).serialize(),
            success: function(){
                $.ajax({url:'krs/list.php', type:'get', success:function(res){ $('#contentData').html(res); }});
            }
        });
    });
    $("#btnBatal").click(function(){
        $.ajax({url:'krs/list.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
});
</script>