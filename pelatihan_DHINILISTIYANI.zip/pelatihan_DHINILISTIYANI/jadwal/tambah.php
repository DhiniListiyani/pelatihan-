<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$dosen = $db->query("select * from tbl_dosen order by nama asc");
$matkul = $db->query("select * from tbl_matkul order by nama asc");
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah Jadwal</h1>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="formTambah">
                <div class="form-group">
                    <label>Mata Kuliah</label>
                    <select class="form-control" name="kd_matkul" required>
                        <option value="">-- Pilih Matkul --</option>
                        <?php while ($m = $matkul->fetch_assoc()) { ?>
                        <option value="<?php echo $m['kd_matkul']; ?>"><?php echo htmlspecialchars($m['nama']); ?> (<?php echo htmlspecialchars($m['sks']); ?>)</option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Dosen</label>
                    <select class="form-control" name="kd_dosen" required>
                        <option value="">-- Pilih Dosen --</option>
                        <?php while ($d = $dosen->fetch_assoc()) { ?>
                        <option value="<?php echo $d['kd_dosen']; ?>"><?php echo htmlspecialchars($d['nama']); ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Waktu</label>
                    <input type="text" class="form-control" name="waktu" placeholder="contoh: 19.00-20.00 WIB" required>
                </div>
                <div class="form-group">
                    <label>Ruang</label>
                    <input type="text" class="form-control" name="ruang" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="#" id="btnBatal" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#formTambah").submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'jadwal/proses_tambah.php', type: 'post', data: $(this).serialize(),
            success: function(){
                $.ajax({url:'jadwal/list.php', type:'get', success:function(res){ $('#contentData').html(res); }});
            }
        });
    });
    $("#btnBatal").click(function(){
        $.ajax({url:'jadwal/list.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
});
</script>