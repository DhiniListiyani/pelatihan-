<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $id        = $koneksi->real_escape_string($_POST['id']);
    $kd_dosen  = $koneksi->real_escape_string($_POST['kd_dosen']);
    $kd_matkul = $koneksi->real_escape_string($_POST['kd_matkul']);
    $waktu     = $koneksi->real_escape_string($_POST['waktu']);
    $ruang     = $koneksi->real_escape_string($_POST['ruang']);

    $sql = "UPDATE tbl_jadwal SET kd_dosen='$kd_dosen', kd_matkul='$kd_matkul', waktu='$waktu', ruang='$ruang' WHERE id='$id'";
    $result = $db->update($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>