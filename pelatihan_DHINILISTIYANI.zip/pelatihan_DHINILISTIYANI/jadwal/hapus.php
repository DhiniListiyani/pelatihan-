<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$koneksi = $db->getKoneksi();
$id = $koneksi->real_escape_string($_GET['id']);

$sql = "DELETE FROM tbl_jadwal WHERE id='$id'";
$result = $db->delete($sql);

$data = $db->query("
    SELECT j.id, j.waktu, j.ruang, d.nama as nama_dosen, m.nama as nama_matkul
    FROM tbl_jadwal j
    JOIN tbl_dosen d ON j.kd_dosen = d.kd_dosen
    JOIN tbl_matkul m ON j.kd_matkul = m.kd_matkul
    ORDER BY j.id ASC
");
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data Jadwal</h1>
        <a href="#" id="btnTambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Jadwal
        </a>
    </div>
    <?php if (!$result) { ?>
        <div class="alert alert-danger">Gagal menghapus data. Kemungkinan jadwal ini masih digunakan pada KRS.</div>
    <?php } ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead><tr><th>No</th><th>Mata Kuliah</th><th>Dosen</th><th>Waktu</th><th>Ruang</th><th>Aksi</th></tr></thead>
                    <tbody>
                        <?php $no = 1; while ($row = $data->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($row['nama_matkul']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_dosen']); ?></td>
                            <td><?php echo htmlspecialchars($row['waktu']); ?></td>
                            <td><?php echo htmlspecialchars($row['ruang']); ?></td>
                            <td>
                                <a href="#" class="btn btn-warning btn-sm btn-edit" data-id="<?php echo $row['id']; ?>"><i class="fas fa-edit"></i> Edit</a>
                                <a href="#" class="btn btn-danger btn-sm btn-hapus" data-id="<?php echo $row['id']; ?>"><i class="fas fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#btnTambah").click(function(){
        $.ajax({url:'jadwal/tambah.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
    $(".btn-edit").click(function(){
        var id = $(this).data('id');
        $.ajax({url:'jadwal/edit.php', type:'get', data:{id:id}, success:function(data){ $('#contentData').html(data); }});
    });
    $(".btn-hapus").click(function(){
        var id = $(this).data('id');
        if(confirm('Yakin ingin menghapus data jadwal ini?')){
            $.ajax({url:'jadwal/hapus.php', type:'get', data:{id:id}, success:function(data){ $('#contentData').html(data); }});
        }
    });
});
</script>