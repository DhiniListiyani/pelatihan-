<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $kd_dosen  = $koneksi->real_escape_string($_POST['kd_dosen']);
    $kd_matkul = $koneksi->real_escape_string($_POST['kd_matkul']);
    $waktu     = $koneksi->real_escape_string($_POST['waktu']);
    $ruang     = $koneksi->real_escape_string($_POST['ruang']);

    $sql = "INSERT INTO tbl_jadwal (kd_dosen, kd_matkul, waktu, ruang) VALUES ('$kd_dosen','$kd_matkul','$waktu','$ruang')";
    $result = $db->insert($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>