<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) {
    echo "Sesi habis, silakan login ulang.";
    exit;
}
include "../db.php";
$db = new db;
$data = $db->query("
    SELECT mh.nim, mh.nama as nama_mhs, mk.nama as nama_matkul, jd.waktu, jd.ruang
    FROM tbl_krs k
    JOIN tbl_mahasiswa mh ON k.nim = mh.nim
    JOIN tbl_jadwal jd ON k.id_jadwal = jd.id
    JOIN tbl_matkul mk ON jd.kd_matkul = mk.kd_matkul
    ORDER BY mh.nama ASC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan Mahasiswa & Jadwal</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
            color: #222;
            margin: 30px;
        }
        .kop {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .kop h2 { margin: 0; font-size: 18px; }
        .kop p { margin: 2px 0 0 0; font-size: 12px; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #333;
            padding: 6px 8px;
            text-align: left;
        }
        th { background-color: #f0f0f0; text-align: center; }
        td.center { text-align: center; }
        .footer-tanda {
            margin-top: 60px;
            display: flex;
            justify-content: flex-end;
        }
        .footer-tanda .kolom { text-align: center; width: 220px; }
        .footer-tanda .garis { margin-top: 60px; border-top: 1px solid #333; }
        @media print {
            .no-print { display: none; }
            body { margin: 0; }
        }
        .btn-print {
            background: #4e73df;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
    </style>
</head>
<body onload="window.print()">

    <div class="no-print" style="text-align:right; margin-bottom:15px;">
        <button class="btn-print" onclick="window.print()">Cetak / Simpan sebagai PDF</button>
    </div>

    <div class="kop">
        <h2>LAPORAN DATA MAHASISWA DAN JADWAL</h2>
        <p>Pelatihan Irwan Maulana</p>
        <p>Dicetak pada: <?php echo date("d-m-Y H:i"); ?> WIB</p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>NIM</th>
                <th>Nama Mahasiswa</th>
                <th>Mata Kuliah</th>
                <th>Jadwal</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; while ($row = $data->fetch_assoc()) { ?>
            <tr>
                <td class="center"><?php echo $no++; ?></td>
                <td class="center"><?php echo $row['nim']; ?></td>
                <td><?php echo htmlspecialchars($row['nama_mhs']); ?></td>
                <td><?php echo htmlspecialchars($row['nama_matkul']); ?></td>
                <td><?php echo htmlspecialchars($row['waktu']) . ' - ' . htmlspecialchars($row['ruang']); ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="footer-tanda">
        <div class="kolom">
            <p>Tangerang Selatan, <?php echo date("d-m-Y"); ?></p>
            <p>Admin</p>
            <div class="garis"></div>
        </div>
    </div>

</body>
</html>