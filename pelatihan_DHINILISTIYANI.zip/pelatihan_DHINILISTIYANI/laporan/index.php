<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$data = $db->query("
    SELECT mh.nim, mh.nama as nama_mhs, mk.nama as nama_matkul, jd.waktu, jd.ruang
    FROM tbl_krs k
    JOIN tbl_mahasiswa mh ON k.nim = mh.nim
    JOIN tbl_jadwal jd ON k.id_jadwal = jd.id
    JOIN tbl_matkul mk ON jd.kd_matkul = mk.kd_matkul
    ORDER BY mh.nama ASC
");
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Laporan Mahasiswa & Jadwal</h1>
        <a href="laporan/cetak_pdf.php" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm">
            <i class="fas fa-file-pdf fa-sm text-white-50"></i> Cetak / Export PDF
        </a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Nama Mahasiswa</th>
                            <th>Mata Kuliah</th>
                            <th>Jadwal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = $data->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $row['nim']; ?></td>
                            <td><?php echo htmlspecialchars($row['nama_mhs']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_matkul']); ?></td>
                            <td><?php echo htmlspecialchars($row['waktu']) . ' - ' . htmlspecialchars($row['ruang']); ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>