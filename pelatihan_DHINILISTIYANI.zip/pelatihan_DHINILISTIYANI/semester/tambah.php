<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah Semester</h1>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="formTambah">
                <div class="form-group">
                    <label>Kode Semester</label>
                    <input type="number" class="form-control" name="kd_semester" required>
                </div>
                <div class="form-group">
                    <label>Semester</label>
                    <input type="text" class="form-control" name="semester" placeholder="contoh: Ganjil 2023/2024" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="#" id="btnBatal" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#formTambah").submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'semester/proses_tambah.php', type: 'post', data: $(this).serialize(),
            success: function(){
                $.ajax({url:'semester/list.php', type:'get', success:function(res){ $('#contentData').html(res); }});
            }
        });
    });
    $("#btnBatal").click(function(){
        $.ajax({url:'semester/list.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
});
</script>