<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$koneksi = $db->getKoneksi();
$kd_semester = $koneksi->real_escape_string($_GET['kd_semester']);
$data = $db->query("select * from tbl_semester where kd_semester='$kd_semester'");
$row = $data->fetch_assoc();
if (!$row) { echo "Data tidak ditemukan."; exit; }
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Semester</h1>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="formEdit">
                <div class="form-group">
                    <label>Kode Semester</label>
                    <input type="number" class="form-control" name="kd_semester" value="<?php echo $row['kd_semester']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Semester</label>
                    <input type="text" class="form-control" name="semester" value="<?php echo htmlspecialchars($row['semester']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="#" id="btnBatal" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#formEdit").submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'semester/update.php', type: 'post', data: $(this).serialize(),
            success: function(){
                $.ajax({url:'semester/list.php', type:'get', success:function(res){ $('#contentData').html(res); }});
            }
        });
    });
    $("#btnBatal").click(function(){
        $.ajax({url:'semester/list.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
});
</script>