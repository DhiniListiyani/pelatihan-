<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $kd_semester = $koneksi->real_escape_string($_POST['kd_semester']);
    $semester    = $koneksi->real_escape_string($_POST['semester']);

    $sql = "INSERT INTO tbl_semester (kd_semester, semester) VALUES ('$kd_semester','$semester')";
    $result = $db->insert($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>