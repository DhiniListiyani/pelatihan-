<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$koneksi = $db->getKoneksi();
$kd_semester = $koneksi->real_escape_string($_GET['kd_semester']);

$sql = "DELETE FROM tbl_semester WHERE kd_semester='$kd_semester'";
$result = $db->delete($sql);

$data = $db->query("select * from tbl_semester order by kd_semester asc");
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data Semester</h1>
        <a href="#" id="btnTambah" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Semester
        </a>
    </div>
    <?php if (!$result) { ?>
        <div class="alert alert-danger">Gagal menghapus data. Kemungkinan data semester ini masih digunakan pada KRS.</div>
    <?php } ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead><tr><th>No</th><th>Kode Semester</th><th>Semester</th><th>Aksi</th></tr></thead>
                    <tbody>
                        <?php $no = 1; while ($row = $data->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $row['kd_semester']; ?></td>
                            <td><?php echo htmlspecialchars($row['semester']); ?></td>
                            <td>
                                <a href="#" class="btn btn-warning btn-sm btn-edit" data-id="<?php echo $row['kd_semester']; ?>"><i class="fas fa-edit"></i> Edit</a>
                                <a href="#" class="btn btn-danger btn-sm btn-hapus" data-id="<?php echo $row['kd_semester']; ?>"><i class="fas fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#btnTambah").click(function(){
        $.ajax({url:'semester/tambah.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
    $(".btn-edit").click(function(){
        var id = $(this).data('id');
        $.ajax({url:'semester/edit.php', type:'get', data:{kd_semester:id}, success:function(data){ $('#contentData').html(data); }});
    });
    $(".btn-hapus").click(function(){
        var id = $(this).data('id');
        if(confirm('Yakin ingin menghapus data semester ini?')){
            $.ajax({url:'semester/hapus.php', type:'get', data:{kd_semester:id}, success:function(data){ $('#contentData').html(data); }});
        }
    });
});
</script>