<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $kd_matkul = $koneksi->real_escape_string($_POST['kd_matkul']);
    $nama      = $koneksi->real_escape_string($_POST['nama']);
    $sks       = $koneksi->real_escape_string($_POST['sks']);

    $sql = "UPDATE tbl_matkul SET nama='$nama', sks='$sks' WHERE kd_matkul='$kd_matkul'";
    $result = $db->update($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>