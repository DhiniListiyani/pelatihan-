<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;
$koneksi = $db->getKoneksi();
$kd_matkul = $koneksi->real_escape_string($_GET['kd_matkul']);
$data = $db->query("select * from tbl_matkul where kd_matkul='$kd_matkul'");
$row = $data->fetch_assoc();
if (!$row) { echo "Data tidak ditemukan."; exit; }
?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Mata Kuliah</h1>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form id="formEdit">
                <div class="form-group">
                    <label>Kode Matkul</label>
                    <input type="number" class="form-control" name="kd_matkul" value="<?php echo $row['kd_matkul']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Nama Matkul</label>
                    <input type="text" class="form-control" name="nama" value="<?php echo htmlspecialchars($row['nama']); ?>" required>
                </div>
                <div class="form-group">
                    <label>SKS</label>
                    <input type="text" class="form-control" name="sks" value="<?php echo htmlspecialchars($row['sks']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="#" id="btnBatal" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    $("#formEdit").submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'matkul/update.php', type: 'post', data: $(this).serialize(),
            success: function(){
                $.ajax({url:'matkul/list.php', type:'get', success:function(res){ $('#contentData').html(res); }});
            }
        });
    });
    $("#btnBatal").click(function(){
        $.ajax({url:'matkul/list.php', type:'get', success:function(data){ $('#contentData').html(data); }});
    });
});
</script>