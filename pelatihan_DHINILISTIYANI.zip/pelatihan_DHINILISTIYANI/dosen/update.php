<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $kd_dosen = $koneksi->real_escape_string($_POST['kd_dosen']);
    $nama     = $koneksi->real_escape_string($_POST['nama']);
    $alamat   = $koneksi->real_escape_string($_POST['alamat']);

    $sql = "UPDATE tbl_dosen SET nama='$nama', alamat='$alamat' WHERE kd_dosen='$kd_dosen'";
    $result = $db->update($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>