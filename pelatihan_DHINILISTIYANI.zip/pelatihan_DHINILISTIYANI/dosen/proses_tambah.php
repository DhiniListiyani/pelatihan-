<?php
session_start();
if (!isset($_SESSION['status']) || $_SESSION['status'] !== true) { echo "Sesi habis, silakan login ulang."; exit; }
include "../db.php";
$db = new db;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = $db->getKoneksi();
    $kd_dosen = $koneksi->real_escape_string($_POST['kd_dosen']);
    $nama     = $koneksi->real_escape_string($_POST['nama']);
    $alamat   = $koneksi->real_escape_string($_POST['alamat']);

    $sql = "INSERT INTO tbl_dosen (kd_dosen, nama, alamat) VALUES ('$kd_dosen','$nama','$alamat')";
    $result = $db->insert($sql);
    echo $result ? "sukses" : "gagal: " . $koneksi->error;
}
?>